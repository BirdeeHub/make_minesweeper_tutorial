#!/bin/bash
LaunchDir="/usr/local/bin"
sudo rm $LaunchDir/minesweeper
sudo dpkg --purge minesweeper
